import { useMemo, useState } from 'react';
import { ArrowDown, ArrowRight, ArrowUpRight, Clock3, Instagram, MapPin, Menu as MenuIcon, Phone, Star, Utensils, X } from 'lucide-react';
import { siteConfig } from '@/data/siteConfig';

const categories = ['Everything', ...Array.from(new Set(siteConfig.menu.map((item) => item.category)))];

function SafeImage({ src, alt, className = '' }: { src: string; alt: string; className?: string }) {
  const [failed, setFailed] = useState(false);
  if (failed) {
    return <div role="img" aria-label={alt} className={`flex items-center justify-center bg-[#ded1b8] text-[#526449] ${className}`}><Utensils size={30} strokeWidth={1.3} /></div>;
  }
  return <img src={src} alt={alt} className={className} loading="eager" onError={() => setFailed(true)} />;
}

function App() {
  const [activeCategory, setActiveCategory] = useState('Everything');
  const [mobileNavOpen, setMobileNavOpen] = useState(false);
  const [activePhoto, setActivePhoto] = useState<number | null>(null);
  const filteredMenu = useMemo(
    () => siteConfig.menu.filter((item) => activeCategory === 'Everything' || item.category === activeCategory),
    [activeCategory],
  );
  const closeNav = () => setMobileNavOpen(false);

  return (
    <div className="grain min-h-[100dvh] bg-[#f7f4eb] text-[#302c25]">
      <div className="bg-[#354d3e] px-4 py-2 text-center text-[10px] font-semibold tracking-[.14em] text-[#f4eedf] sm:text-[11px]" data-testid="notice-demo">
        FICTIONAL RESTAURANT DEMO · ALL DETAILS ARE SAMPLE CONTENT
      </div>
      <header className="sticky top-0 z-40 border-b border-[#e5dfd2] bg-[#f7f4eb]/95 backdrop-blur-md">
        <div className="section-wrap flex h-[76px] items-center justify-between">
          <a href="#home" className="flex items-center gap-3 no-underline" aria-label="Saffron and Stone home" data-testid="link-home">
            <span className="grid h-10 w-10 place-items-center rounded-full border border-[#b6aa91] text-[#3a5443]"><span className="serif text-[21px] leading-none">S</span></span>
            <span className="leading-tight">
              <span className="serif block text-[18px] font-semibold tracking-[-.035em] text-[#334638]">Saffron <span className="text-[#a65c42]">&</span> Stone</span>
              <span className="mt-1 block text-[8px] font-bold uppercase tracking-[.24em] text-[#857c6a]">Seasonal Mediterranean</span>
            </span>
          </a>
          <nav className="hidden items-center gap-8 md:flex" aria-label="Main navigation">
            {['Our story', 'Menu', 'The space', 'Visit'].map((item) => <a key={item} href={`#${item === 'Our story' ? 'about' : item === 'The space' ? 'gallery' : item.toLowerCase()}`} className="text-[12px] font-semibold text-[#565146] no-underline transition-colors hover:text-[#a65c42]" data-testid={`link-nav-${item.toLowerCase().replaceAll(' ', '-')}`}>{item}</a>)}
          </nav>
          <div className="hidden items-center gap-5 md:flex">
            <a href={`tel:${siteConfig.phoneLink}`} className="flex items-center gap-2 text-[12px] font-semibold text-[#455747] no-underline" data-testid="link-header-call"><Phone size={14} /> <span>Give us a ring</span></a>
            <a href="#menu" className="rounded-full bg-[#354d3e] px-5 py-3 text-[11px] font-bold tracking-wide text-[#fbf7ec] no-underline transition hover:bg-[#a65c42]" data-testid="link-header-menu">See the menu <ArrowUpRight className="ml-1 inline" size={13} /></a>
          </div>
          <button type="button" onClick={() => setMobileNavOpen((open) => !open)} aria-label={mobileNavOpen ? 'Close navigation' : 'Open navigation'} aria-expanded={mobileNavOpen} className="grid h-10 w-10 place-items-center rounded-full border border-[#ded6c6] text-[#354d3e] md:hidden" data-testid="button-mobile-nav">{mobileNavOpen ? <X size={20} /> : <MenuIcon size={20} />}</button>
        </div>
        {mobileNavOpen && <nav className="border-t border-[#e5dfd2] bg-[#f7f4eb] px-6 py-4 md:hidden" aria-label="Mobile navigation">{[['Our story', '#about'], ['Menu', '#menu'], ['The space', '#gallery'], ['Visit', '#visit']].map(([label, href]) => <a key={label} href={href} onClick={closeNav} className="block border-b border-[#e8e1d4] py-3 text-sm font-semibold text-[#3b493a] no-underline last:border-0" data-testid={`link-mobile-${label.toLowerCase().replaceAll(' ', '-')}`}>{label}</a>)}</nav>}
      </header>

      <main>
        <section id="home" className="relative flex min-h-[650px] items-center overflow-hidden bg-[#343c32] sm:min-h-[690px]">
          <SafeImage src="/images/hero-table.jpg" alt="A candlelit table filled with Mediterranean dishes" className="absolute inset-0 h-full w-full object-cover object-center" />
          <div className="absolute inset-0 bg-gradient-to-r from-[#18251e]/85 via-[#18251e]/55 to-[#18251e]/10" />
          <div className="section-wrap relative z-10 grid w-full grid-cols-1 items-center py-20 md:grid-cols-[1.1fr_.9fr]">
            <div className="max-w-[620px] text-[#fbf6e9]">
              <div className="eyebrow mb-7 flex items-center gap-3 text-[#dfb791]"><span className="h-px w-8 bg-[#dfb791]" /> Neighbors first. Always.</div>
              <h1 className="serif max-w-[650px] text-[clamp(3.5rem,8vw,6.8rem)] leading-[.98] tracking-[-.055em]">Come hungry.<br /><em className="font-medium text-[#e5b893]">Leave family.</em></h1>
              <p className="mt-7 max-w-[440px] text-[15px] leading-7 text-[#f6efdf]/85 sm:text-[17px]">Seasonal Mediterranean cooking, generous pours, and one more place at the table. Right here in the neighborhood.</p>
              <div className="mt-9 flex flex-wrap items-center gap-4">
                <a href="#menu" className="inline-flex items-center gap-3 rounded-full bg-[#f1e4ce] px-6 py-4 text-[12px] font-bold text-[#354d3e] no-underline transition hover:bg-white" data-testid="link-explore-menu">Explore the menu <ArrowRight size={15} /></a>
                <a href="#about" className="inline-flex items-center gap-2 px-2 py-3 text-[12px] font-semibold text-[#fbf6e9] no-underline hover:text-[#e5b893]" data-testid="link-hero-story">A little about us <ArrowDown size={14} /></a>
              </div>
              <div className="mt-12 flex items-center gap-3 text-[11px] text-[#f6efdf]/75"><span className="flex text-[#e5b893]"><Star size={13} fill="currentColor" /><Star size={13} fill="currentColor" /><Star size={13} fill="currentColor" /><Star size={13} fill="currentColor" /><Star size={13} fill="currentColor" /></span><span>Local love, served daily</span><span className="mx-1 h-1 w-1 rounded-full bg-[#e5b893]" /><span>Sample restaurant</span></div>
            </div>
            <div className="hidden justify-end md:flex">
              <div className="mt-48 rotate-3 rounded-[2px] border border-white/20 bg-[#f7f0e4]/95 p-5 text-[#374a3b] shadow-2xl">
                <span className="eyebrow text-[#a65c42]">A note from our kitchen</span>
                <p className="serif mt-3 max-w-[180px] text-[24px] leading-tight">Good food is<br />better shared.</p>
                <span className="mt-4 block text-[9px] font-bold uppercase tracking-[.18em] text-[#7c7567]">Pull up a chair</span>
              </div>
            </div>
          </div>
          <div className="absolute bottom-7 right-8 hidden items-center gap-3 text-[9px] uppercase tracking-[.2em] text-white/65 lg:flex"><span className="h-px w-9 bg-white/45" /> Scroll a little</div>
        </section>

        <section id="about" className="section-wrap grid gap-12 py-24 md:grid-cols-[.86fr_1.14fr] md:items-center md:gap-24 md:py-32">
          <div className="relative mx-auto w-full max-w-[440px]">
            <div className="photo-zoom overflow-hidden rounded-t-[48%] rounded-b-[5px] shadow-xl">
              <SafeImage src="/images/dish-falafel.jpg" alt="Bright herbs and pomegranate over a Mediterranean mezze plate" className="h-[430px] w-full object-cover" />
            </div>
            <div className="absolute -bottom-5 -right-3 rounded-full border border-[#c7bba3] bg-[#f7f4eb] px-5 py-4 text-center text-[#405243] shadow-sm sm:-right-8"><span className="serif block text-2xl">Since day one</span><span className="eyebrow mt-1 block text-[8px] text-[#887b64]">Made for this neighborhood</span></div>
          </div>
          <div className="max-w-[540px]">
            <p className="eyebrow mb-5 text-[#a65c42]">A table with room for one more</p>
            <h2 className="serif text-[clamp(2.65rem,5vw,4.4rem)] leading-[1.07] tracking-[-.045em] text-[#354d3e]">The best meals<br />feel like <em>coming home.</em></h2>
            <p className="mt-7 text-[15px] leading-7 text-[#686153]">Saffron & Stone is the kind of place where lunch lingers into late afternoon and the last piece of bread is always up for grabs. Our kitchen follows the seasons, borrowing a little from the Mediterranean and making it feel right at home on Valencia Street.</p>
            <p className="mt-4 text-[15px] leading-7 text-[#686153]">Come as you are. Bring the whole crew. We’ll find another chair.</p>
            <a href="#visit" className="mt-7 inline-flex items-center gap-3 border-b border-[#a65c42] pb-2 text-[12px] font-bold text-[#354d3e] no-underline" data-testid="link-about-visit">Come say hello <ArrowRight size={15} /></a>
          </div>
        </section>

        <section id="menu" className="bg-[#ede8dc] py-20 md:py-28">
          <div className="section-wrap">
            <div className="flex flex-col justify-between gap-7 md:flex-row md:items-end">
              <div><p className="eyebrow mb-4 text-[#a65c42]">Cooked with the season</p><h2 className="serif text-[clamp(2.8rem,5vw,4.6rem)] leading-none tracking-[-.045em] text-[#354d3e]">A menu for sharing.</h2><p className="mt-4 max-w-[480px] text-[14px] leading-6 text-[#696252]">A few things we’re loving right now. Everything’s made to order, with a little room for whatever the market brings.</p></div>
              <span className="eyebrow max-w-[190px] text-[9px] leading-5 text-[#867d6b]">The menu changes with the market · sample prices</span>
            </div>
            <div className="mt-9 flex gap-2 overflow-x-auto pb-2" role="group" aria-label="Filter menu by category">
              {categories.map((category) => <button key={category} type="button" onClick={() => setActiveCategory(category)} aria-pressed={activeCategory === category} className={`shrink-0 rounded-full border px-4 py-2.5 text-[11px] font-semibold transition ${activeCategory === category ? 'border-[#354d3e] bg-[#354d3e] text-[#fbf6e9]' : 'border-[#cfc5b1] bg-transparent text-[#5c584d] hover:border-[#354d3e]'}`} data-testid={`button-filter-${category.toLowerCase().replaceAll(' ', '-')}`}>{category}</button>)}
            </div>
            <div className="mt-5 grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
              {filteredMenu.map((item) => <article key={item.id} className="food-card group overflow-hidden rounded-[5px] border border-[#ded6c6] bg-[#faf8f1] shadow-[0_7px_20px_rgba(57,45,28,.055)]" data-testid={`card-menu-${item.id}`}>
                <div className="photo-zoom relative h-[210px] overflow-hidden bg-[#e4dbc9]">
                  <SafeImage src={item.image} alt={item.name} className="h-full w-full object-cover" />
                  {item.label && <span className="absolute left-4 top-4 rounded-full bg-[#f7f2e7]/95 px-3 py-1.5 text-[9px] font-bold uppercase tracking-[.12em] text-[#475744]">{item.label}</span>}
                </div>
                <div className="p-5">
                  <div className="flex items-start justify-between gap-3"><h3 className="serif text-[20px] leading-tight text-[#344a39]">{item.name}</h3><span className="shrink-0 text-[14px] font-semibold text-[#a65c42]">{item.price}</span></div>
                  <p className="mt-2 text-[12px] leading-5 text-[#716a5c]">{item.description}</p>
                </div>
              </article>)}
            </div>
            <p className="mt-6 text-[10px] text-[#827967]">Menu shown is sample content for demonstration purposes. Ask us about dietary needs.</p>
          </div>
        </section>

        <section className="relative overflow-hidden bg-[#354d3e] py-20 text-[#f7f1e4] md:py-24">
          <div className="absolute -right-24 -top-40 h-[440px] w-[440px] rounded-full border border-white/10" /><div className="absolute -right-10 -top-24 h-[350px] w-[350px] rounded-full border border-white/10" />
          <div className="section-wrap relative grid gap-10 md:grid-cols-[.75fr_1.25fr] md:items-center">
            <div><p className="eyebrow mb-5 text-[#dfb791]">A few things worth saving room for</p><h2 className="serif text-[clamp(2.8rem,5vw,4.5rem)] leading-[1.03] tracking-[-.04em]">Little plates.<br /><em>Big affection.</em></h2><p className="mt-6 max-w-[340px] text-[14px] leading-6 text-[#f5ecda]/75">Order one more. Pass it around. These are the bites that tend to disappear first.</p></div>
            <div className="grid grid-cols-2 gap-3 sm:gap-5">
              {siteConfig.menu.filter((dish) => ['whipped-feta', 'roast-fish', 'tomato-rigatoni', 'olive-oil-cake'].includes(dish.id)).map((dish, index) => <article key={dish.id} className={`food-card group relative overflow-hidden rounded-[4px] ${index === 1 ? 'mt-8' : ''}`}>
                <div className="photo-zoom h-[210px] overflow-hidden sm:h-[260px]"><SafeImage src={dish.image} alt={dish.name} className="h-full w-full object-cover" /></div>
                <div className="absolute inset-x-0 bottom-0 bg-gradient-to-t from-[#15251b]/90 to-transparent px-4 pb-4 pt-14 text-[#fff8e9]"><span className="serif text-[18px] sm:text-[21px]">{dish.name}</span><span className="mt-1 block text-[10px] text-white/75">{dish.price} · A house favorite</span></div>
              </article>)}
            </div>
          </div>
        </section>

        <section id="gallery" className="section-wrap py-20 md:py-28">
          <div className="mb-9 flex flex-col justify-between gap-5 sm:flex-row sm:items-end"><div><p className="eyebrow mb-4 text-[#a65c42]">A seat at our table</p><h2 className="serif text-[clamp(2.8rem,5vw,4.4rem)] leading-none tracking-[-.045em] text-[#354d3e]">A little look around.</h2></div><p className="max-w-[280px] text-[13px] leading-6 text-[#716a5c]">The good plates, the golden hour, and always something in the middle to share.</p></div>
          <div className="grid grid-cols-2 gap-3 md:grid-cols-4">
            {siteConfig.gallery.map((photo, index) => <button key={photo.src} type="button" onClick={() => setActivePhoto(index)} aria-label={`View photo: ${photo.alt}`} className={`photo-zoom group relative overflow-hidden rounded-[4px] bg-[#ded4c2] text-left ${index === 0 ? 'col-span-2 row-span-2 h-[300px] md:h-[430px]' : 'h-[143px] sm:h-[200px] md:h-[207px]'}`} data-testid={`button-gallery-${index + 1}`}><SafeImage src={photo.src} alt={photo.alt} className="h-full w-full object-cover" /><span className="absolute inset-0 bg-[#27372b]/0 transition group-hover:bg-[#27372b]/15" /></button>)}
          </div>
        </section>

        <section className="bg-[#e9e1d2] py-20 md:py-24">
          <div className="section-wrap grid gap-10 md:grid-cols-[.72fr_1.28fr] md:items-center">
            <div><p className="eyebrow mb-4 text-[#a65c42]">Notes from around the table</p><h2 className="serif text-[clamp(2.8rem,5vw,4rem)] leading-[1.05] tracking-[-.04em] text-[#354d3e]">Kind words.<br /><em>Full hearts.</em></h2><div className="mt-7 flex gap-1 text-[#a65c42]" aria-label="Five out of five stars"><Star size={16} fill="currentColor" /><Star size={16} fill="currentColor" /><Star size={16} fill="currentColor" /><Star size={16} fill="currentColor" /><Star size={16} fill="currentColor" /></div><p className="mt-3 text-[11px] text-[#716a5c]">Sample reviews for this fictional restaurant</p></div>
            <div className="grid gap-4 sm:grid-cols-2">
              {[{ quote: '“The sort of dinner that turns into a three-hour catch-up. The crispy artichokes are non-negotiable.”', by: 'Maya R.', note: 'A neighborhood regular' }, { quote: '“Warm, unhurried, and so generous. We left with full bellies and plans to come back next week.”', by: 'Theo & Liv', note: 'First visit, not the last' }].map((review) => <blockquote key={review.by} className="m-0 border border-[#d7cbb7] bg-[#f6f1e7] p-6 sm:p-7"><div className="mb-4 flex gap-1 text-[#a65c42]" aria-hidden="true"><Star size={12} fill="currentColor" /><Star size={12} fill="currentColor" /><Star size={12} fill="currentColor" /><Star size={12} fill="currentColor" /><Star size={12} fill="currentColor" /></div><p className="serif text-[21px] leading-[1.4] text-[#38483b]">{review.quote}</p><footer className="mt-6 border-t border-[#e1d8c8] pt-4"><span className="block text-[11px] font-bold text-[#39493b]">{review.by}</span><span className="mt-1 block text-[10px] text-[#7c7568]">{review.note}</span></footer></blockquote>)}
            </div>
          </div>
        </section>

        <section id="visit" className="section-wrap grid gap-10 py-20 md:grid-cols-[.85fr_1.15fr] md:py-28">
          <div>
            <p className="eyebrow mb-4 text-[#a65c42]">Find your way over</p><h2 className="serif text-[clamp(2.8rem,5vw,4.5rem)] leading-[1.03] tracking-[-.045em] text-[#354d3e]">We saved<br /><em>you a seat.</em></h2>
            <p className="mt-5 max-w-[380px] text-[14px] leading-6 text-[#6c6558]">Come by for a quick bite or settle in for the evening. Walk-ins are always welcome; a heads-up is lovely for larger tables.</p>
            <div className="mt-8 space-y-6">
              <div className="flex gap-4"><MapPin className="mt-1 shrink-0 text-[#a65c42]" size={18} /><div><p className="eyebrow text-[9px] text-[#8e806a]">Find us</p><p className="mt-1 text-[13px] leading-5 text-[#3e493b]">{siteConfig.address}</p><a href={`https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(siteConfig.mapQuery)}`} target="_blank" rel="noreferrer" className="mt-2 inline-flex items-center gap-1 text-[11px] font-bold text-[#a65c42] no-underline" data-testid="link-directions">Get directions <ArrowUpRight size={12} /></a></div></div>
              <div className="flex gap-4"><Clock3 className="mt-1 shrink-0 text-[#a65c42]" size={18} /><div><p className="eyebrow text-[9px] text-[#8e806a]">Pull up a chair</p><div className="mt-2 space-y-1.5">{siteConfig.hours.map((hours) => <p key={hours.day} className="flex min-w-[260px] justify-between gap-5 text-[11px] text-[#544f44]"><span>{hours.day}</span><span className="font-semibold">{hours.time}</span></p>)}</div></div></div>
              <div className="flex flex-wrap gap-3 pt-1"><a href={`tel:${siteConfig.phoneLink}`} className="inline-flex items-center gap-2 rounded-full bg-[#354d3e] px-5 py-3 text-[11px] font-bold text-[#faf5e8] no-underline transition hover:bg-[#a65c42]" data-testid="link-call"><Phone size={14} /> Call {siteConfig.phoneDisplay}</a><a href={siteConfig.whatsappLink} target="_blank" rel="noreferrer" className="inline-flex items-center gap-2 rounded-full border border-[#bcb19d] px-5 py-3 text-[11px] font-bold text-[#354d3e] no-underline transition hover:border-[#354d3e] hover:bg-[#eae4d8]" data-testid="link-whatsapp">Message on WhatsApp <ArrowUpRight size={13} /></a></div>
            </div>
          </div>
          <div className="relative min-h-[370px] overflow-hidden rounded-[4px] border border-[#d9d0bf] bg-[#e6dfd1] shadow-sm">
            <SafeImage src={siteConfig.mapImage} alt="Street map around the fictional Saffron & Stone location in San Francisco" className="absolute inset-0 h-full w-full object-cover grayscale-[.35] sepia-[.12]" />
            <span aria-hidden="true" className="absolute z-10 -translate-x-1/2 -translate-y-full text-[#a65c42] drop-shadow-md" style={{ left: siteConfig.mapPin.left, top: siteConfig.mapPin.top }}><MapPin size={34} fill="#f8f4e9" strokeWidth={2} /></span>
            <div className="pointer-events-none absolute bottom-4 left-4 rounded-sm bg-[#f8f4e9]/95 px-4 py-3 shadow-md"><span className="serif block text-[17px] text-[#344a39]">248 Valencia Street</span><span className="mt-1 block text-[9px] font-semibold uppercase tracking-[.15em] text-[#877b68]">San Francisco · Demo location</span></div>
            <a href="https://www.openstreetmap.org/copyright" target="_blank" rel="noreferrer" className="absolute bottom-1 right-2 rounded bg-white/90 px-1.5 py-0.5 text-[9px] text-[#4b5148] no-underline">© OpenStreetMap</a>
          </div>
        </section>
      </main>

      <footer className="bg-[#273b2f] text-[#f5efdf]">
        <div className="section-wrap grid gap-10 py-12 md:grid-cols-[1fr_auto_1fr] md:items-center">
          <a href="#home" className="w-fit no-underline" data-testid="link-footer-home"><span className="serif block text-[24px] tracking-[-.035em]">Saffron <span className="text-[#d8a787]">&</span> Stone</span><span className="eyebrow mt-1 block text-[8px] text-[#c5b9a2]">A little Mediterranean, a lot of heart.</span></a>
          <nav className="flex flex-wrap gap-x-6 gap-y-3 text-[11px] text-[#e2daca]" aria-label="Footer navigation">{[['Our story', '#about'], ['Menu', '#menu'], ['Gallery', '#gallery'], ['Visit', '#visit']].map(([label, href]) => <a key={label} href={href} className="text-inherit no-underline hover:text-white" data-testid={`link-footer-${label.toLowerCase().replaceAll(' ', '-')}`}>{label}</a>)}</nav>
          <div className="flex items-center gap-3 md:justify-end"><a href={siteConfig.social.instagram} target="_blank" rel="noreferrer" aria-label="Instagram" className="grid h-9 w-9 place-items-center rounded-full border border-white/25 text-[#f5efdf] transition hover:bg-white/10" data-testid="link-instagram"><Instagram size={15} /></a><a href={siteConfig.social.facebook} target="_blank" rel="noreferrer" aria-label="Facebook" className="grid h-9 w-9 place-items-center rounded-full border border-white/25 text-[13px] font-bold text-[#f5efdf] transition hover:bg-white/10" data-testid="link-facebook">f</a><a href={`tel:${siteConfig.phoneLink}`} aria-label="Call restaurant" className="grid h-9 w-9 place-items-center rounded-full border border-white/25 text-[#f5efdf] transition hover:bg-white/10" data-testid="link-footer-call"><Phone size={14} /></a></div>
        </div>
        <div className="border-t border-white/15"><div className="section-wrap flex flex-col gap-2 py-4 text-[9px] text-[#d4c9b4] sm:flex-row sm:items-center sm:justify-between"><span>© 2025 Saffron & Stone · Fictional business demo</span><span>Sample content, address, reviews & contact information. Not a real restaurant.</span></div></div>
      </footer>

      {activePhoto !== null && <div role="dialog" aria-modal="true" aria-label="Gallery image preview" className="fixed inset-0 z-[60] flex items-center justify-center bg-[#1d2921]/90 p-4" onClick={() => setActivePhoto(null)} onKeyDown={(event) => { if (event.key === 'Escape') setActivePhoto(null); }}>
        <button type="button" onClick={() => setActivePhoto(null)} aria-label="Close image preview" className="absolute right-5 top-5 grid h-11 w-11 place-items-center rounded-full bg-[#f7f4eb] text-[#354d3e]" data-testid="button-close-gallery"><X size={20} /></button>
        <div onClick={(event) => event.stopPropagation()} className="max-h-[88vh] max-w-[min(100%,1000px)]"><SafeImage src={siteConfig.gallery[activePhoto].src} alt={siteConfig.gallery[activePhoto].alt} className="max-h-[82vh] max-w-full rounded-sm object-contain shadow-2xl" /><p className="mt-3 text-center text-sm text-[#f7f4eb]">{siteConfig.gallery[activePhoto].alt}</p></div>
      </div>}
    </div>
  );
}

export default App;
