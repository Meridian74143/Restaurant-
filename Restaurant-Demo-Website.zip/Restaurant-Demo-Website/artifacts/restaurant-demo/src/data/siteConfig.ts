/**
 * Saffron & Stone demo content.
 * Edit menu items, prices, image paths, contact details, address and hours here.
 * All business details below are fictional sample content.
 */
export const siteConfig = {
  restaurantName: 'Saffron & Stone',
  tagline: 'A little Mediterranean, a lot of heart.',
  phoneDisplay: '(415) 555-0186',
  phoneLink: '+14155550186',
  whatsappLink: 'https://wa.me/14155550186?text=Hello%20Saffron%20%26%20Stone',
  address: '248 Valencia Street, San Francisco, CA 94103',
  mapQuery: '248 Valencia Street, San Francisco, CA 94103',
  mapImage: '/images/location-map.png',
  mapPin: { left: '59.6%', top: '39%' },
  hours: [
    { day: 'Monday – Thursday', time: '11:30 am – 9:00 pm' },
    { day: 'Friday – Saturday', time: '11:30 am – 10:00 pm' },
    { day: 'Sunday', time: '10:00 am – 8:00 pm' },
  ],
  menu: [
    { id: 'whipped-feta', name: 'Whipped Feta & Warm Honey', category: 'To begin', price: '$14', description: 'Pillowy feta, wildflower honey, sesame, grilled sourdough.', image: '/images/dish-falafel.jpg', label: 'A house favorite' },
    { id: 'crispy-artichokes', name: 'Crispy Little Artichokes', category: 'To begin', price: '$16', description: 'Lemon, parsley, smoked sea salt, a very good aioli.', image: '/images/dish-falafel.jpg' },
    { id: 'market-greens', name: 'Market Greens & Stone Fruit', category: 'To begin', price: '$17', description: 'Whatever looked lovely this morning, toasted pistachio, herbs.', image: '/images/dish-fish.jpg', label: 'Seasonal' },
    { id: 'roast-fish', name: 'Wood-Roasted Catch', category: 'From the fire', price: '$32', description: 'Today’s local fish, fennel, charred lemon, caper butter.', image: '/images/dish-fish.jpg', label: 'Chef’s pick' },
    { id: 'lamb-meatballs', name: 'Lamb & Mint Meatballs', category: 'From the fire', price: '$29', description: 'Tomato sugo, cool yogurt, torn flatbread for the table.', image: '/images/dish-pasta.jpg' },
    { id: 'market-chicken', name: 'Sunday-Style Roast Chicken', category: 'From the fire', price: '$28', description: 'Crisp skin, little potatoes, olives, pan juices.', image: '/images/dish-fish.jpg' },
    { id: 'tomato-rigatoni', name: 'Rigatoni Pomodoro', category: 'A little more', price: '$24', description: 'Slow-roasted tomatoes, basil, pecorino, olive oil.', image: '/images/dish-pasta.jpg', label: 'Vegetarian' },
    { id: 'herb-falafel', name: 'Green Herb Falafel Plate', category: 'A little more', price: '$23', description: 'Crisp falafel, lemony hummus, pickled things, warm pita.', image: '/images/dish-falafel.jpg' },
    { id: 'olive-oil-cake', name: 'Olive Oil Cake', category: 'Something sweet', price: '$12', description: 'Citrus-scented, softly golden, crème fraîche on the side.', image: '/images/dish-pasta.jpg' },
    { id: 'pistachio-sundae', name: 'Pistachio & Honey Sundae', category: 'Something sweet', price: '$13', description: 'Vanilla bean gelato, toasted pistachio, warm honey.', image: '/images/dish-falafel.jpg' },
  ],
  gallery: [
    { src: '/images/hero-table.jpg', alt: 'A generous Mediterranean table set for dinner' },
    { src: '/images/dish-falafel.jpg', alt: 'Herby falafel with labneh, pomegranate and mint' },
    { src: '/images/dish-fish.jpg', alt: 'Wood-roasted fish with charred lemon and herbs' },
    { src: '/images/dish-pasta.jpg', alt: 'Rigatoni pomodoro with fresh basil and pecorino' },
  ],
  social: {
    instagram: 'https://www.instagram.com/',
    facebook: 'https://www.facebook.com/',
  },
};
